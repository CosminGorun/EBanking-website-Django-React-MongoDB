import React from 'react';

function AccountInfo({ account }) {
  return (
    <div>
      <p>Soldul contului este {account.sold} </p>
      <p>Ibanul contului este {account.iban} </p>
    </div>
  );
}

export default AccountInfo;
