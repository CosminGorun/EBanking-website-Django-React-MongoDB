import React from 'react';
import axios from 'axios';

function Transactions({ listTransferOUT, listTransferIN }) {
  const handleTransferAction = async (IDTransfer, action) => {
    try {
      await axios.post('/finalizareTransfer', {
        IDTransfer,
        action,
      });
      alert(`Transfer ${action}ed`);
    } catch (err) {
      alert(`Failed to ${action} transfer`);
    }
  };

  const handleCancelTransfer = async (IDTransfer) => {
    try {
      await axios.post('/cancelTransfer', { IDTransfer });
      alert('Transfer canceled');
    } catch (err) {
      alert('Failed to cancel transfer');
    }
  };

  return (
    <div>
      <h2>Tranzactii primite</h2>
      {listTransferOUT.map((transfer) => (
        <div key={transfer.IDTransfer}>
          <p>IBAN primire: {transfer.IBANtrimite}</p>
          <p>Suma: {transfer.sumaTransfer} RON</p>
          <p>Data: {transfer.dataTranzactiei}</p>
          <button onClick={() => handleTransferAction(transfer.IDTransfer, 'accept')}>Accepta bani</button>
          <button onClick={() => handleTransferAction(transfer.IDTransfer, 'reject')}>Respinge transferul</button>
        </div>
      ))}
      <h2>Tranzactii trimise</h2>
      {listTransferIN.map((transfer) => (
        <div key={transfer.IDTransfer}>
          <p>IBAN trimitere: {transfer.IBANprimeste}</p>
          <p>Suma: {transfer.sumaTransfer} RON</p>
          <p>Data: {transfer.dataTranzactiei}</p>
          <button onClick={() => handleCancelTransfer(transfer.IDTransfer)}>Cancel</button>
        </div>
      ))}
    </div>
  );
}

export default Transactions;
