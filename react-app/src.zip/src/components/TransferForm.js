import React, { useState } from 'react';
import axios from 'axios';

function TransferForm({ user, account, setError }) {
  const [ibanDestinatie, setIbanDestinatie] = useState('');
  const [suma, setSuma] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/transferConturi', {
        ibanDestinatie,
        suma,
        ibanSursa: account.iban,
        userID: user.userID,
      });
      setError('');
      alert('Transfer successfully submitted');
    } catch (err) {
      setError('Failed to submit transfer');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Iban Destinatie:
        <input
          type="text"
          value={ibanDestinatie}
          onChange={(e) => setIbanDestinatie(e.target.value)}
        />
      </label>
      <br />
      <label>
        Suma:
        <input
          type="text"
          value={suma}
          onChange={(e) => setSuma(e.target.value)}
        />
      </label>
      <br />
      <input type="submit" value="Transfer" />
    </form>
  );
}

export default TransferForm;
