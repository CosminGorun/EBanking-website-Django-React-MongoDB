import React, { useState, useEffect } from 'react';
import AccountInfo from './components/AccountInfo';
import TransferForm from './components/TransferForm';
import Transactions from './components/Transactions';

function App() {
  const [user, setUser] = useState({ name: 'John Doe', userID: '12345' });
  const [account, setAccount] = useState({ sold: 1000, iban: 'RO123456789' });
  const [error, setError] = useState('');
  const [listTransferOUT, setListTransferOUT] = useState([]);
  const [listTransferIN, setListTransferIN] = useState([]);

  useEffect(() => {
    setListTransferOUT([
      { IDTransfer: '1', IBANtrimite: 'RO987654321', sumaTransfer: 100, dataTranzactiei: '2024-11-10' },
    ]);
    setListTransferIN([
      { IDTransfer: '2', IBANprimeste: 'RO123456789', sumaTransfer: 200, dataTranzactiei: '2024-11-09' },
    ]);
  }, []);

  return (
    <div>
      <h1>Hello {user.name} cu id {user.userID}</h1>
      <AccountInfo account={account} />
      <TransferForm user={user} account={account} setError={setError} />
      <h3>{error}</h3>
      <Transactions listTransferOUT={listTransferOUT} listTransferIN={listTransferIN} />
    </div>
  );
}

export default App;
